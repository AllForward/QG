#include <stdio.h>
#include <stdlib.h>
#include "duLinkedList.h"
#define len sizeof(struct DuLNode) 
/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	if((*L=(DuLinkedList)malloc(len))==NULL){
		printf("����ռ�ʧ��!\n");
		return ERROR;
	}
	(*L)->next=NULL,(*L)->prior=NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	DuLinkedList target=NULL;
	while(*L!=NULL){
		if((*L)->next==NULL){
			free(*L);
			*L=NULL;
		}else{
		target=(*L)->next->next;
		free((*L)->next);
		(*L)->next=target;}
	}
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	int data,i;
	printf("���������Ԫ�ص�����:\n");
	i=scanf("%d",&data);
	if(i==1){
			q=(DuLinkedList)malloc(len);
			q->data=data;
			if(p->next==NULL){
				p->next=q;
				q->prior=p;
				q->next=NULL;}
			else{
				p->next->prior=q;
				q->next=p->next;
				p->next=q;
				q->prior=p;}
			return SUCCESS;
		}
	else {
			printf("�������ݴ���!\n");
			return ERROR;}	
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {
	int data,i;
	printf("���������Ԫ�ص�����:\n");
	i=scanf("%d",&data);
	if(i==1){
			q=(DuLinkedList)malloc(len);
			q->data=data;
			p->next=q;
			q->prior=p;
			q->next=NULL;
			return SUCCESS;
		}
	else {
			printf("�������ݴ���!\n");
			return ERROR;}
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	
	DuLNode* q;
	int j=0,i,loc,length=0;
	for(q=p->next;q!=NULL;q=q->next)
	{
		length++;
	}
	q=p->next;
	printf("������ɾ��Ԫ�ص�λ��:\n");
	scanf("%d",&loc);
	if(p->next==NULL){
		printf("����Ϊ��!\n");
		return ERROR;
	}
	else if(loc==1&&q->next==NULL){
		free(q);
		p->next=NULL;
		printf("ɾ���ɹ�!\n");
		return SUCCESS;
	}
	else if(loc>=1&&loc<=length){
			if (p==NULL||loc<1){
				printf("ɾ��ʧ��!\n"); 
				return ERROR;}	
			else {while(p->next&&j<loc-1){//Ѱ�ҵ�i���ڵ㣬����pָ����ǰ��
				p=p->next;++j; 
				}
			if(!(p->next)||j>loc-1)return ERROR;
			q=p->next;	
			p->next=p->next->next;
			p->next->prior=p;
			*e=q->data;free(q);
			printf("ɾ���ɹ�!\n");
			return SUCCESS;}
		}
	else{
		printf("�������ݴ���!\n");
		return ERROR;}
	printf("ɾ���ɹ�!\n");
	return SUCCESS;
}
 
/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit 
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
	DuLNode* target=L->next;
	if(target==NULL){
		printf("����Ϊ��!\n");
		return ERROR;
	}
	printf("˫������Ԫ��:\n");
	for(;target!=NULL;target=target->next)
		visit(target->data);
	printf("\n");
	return SUCCESS;
}

