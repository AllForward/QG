#include <stdio.h>
#include <stdlib.h>
#include "linkedList.h"
#define len sizeof(struct LNode) 
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L){
	*L=(LNode*)malloc(len);
	(*L)->next=NULL;
	if(L==NULL){
		printf("����ռ�ʧ��!\n");
		return ERROR;
	}
	else return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	LNode *target=(*L)->next,*bef_target;
	while(target!=NULL){
		bef_target=target;
		target=target->next;		
		free(bef_target);
		}
		free(target);
	(*L)->next=NULL;
	free(*L);
	*L=NULL; 
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {//��ͷָ�봫�ݸ�p 
	int data,i;
	printf("���������Ԫ�ص�����:\n");
	i=scanf("%d",&data);
	if(i==1){
			q=(LinkedList)malloc(len);
			q->data=data;
			p->next=q;
			q->next=NULL;
			return SUCCESS;
		}
	else {
			printf("�������ݴ���!\n");
			return ERROR;}	
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e){//��ͷָ�봫�ݸ�p 
	LNode* q;
	int j=0,i,loc,length=0;
	for(q=p->next;q!=NULL;q=q->next)
	{
		length++;
	}
	printf("������ɾ��Ԫ�ص�λ��:\n");
	scanf("%d",&loc);
	if(loc>=1&&loc<=length){
			if (p==NULL||loc<1){
				printf("ɾ��ʧ��!\n"); 
				return ERROR;}	
			else {while(p->next&&j<loc-1){//Ѱ�ҵ�i���ڵ㣬����pָ����ǰ��
				p=p->next;++j; 
				}
			if(!(p->next)||j>loc-1)return ERROR;
			q=p->next;	
			p->next=p->next->next;
			*e=q->data;free(q);
			printf("ɾ���ɹ�!\n");
			return SUCCESS;}
		}
	else{
		printf("�������ݴ���!\n");
		return SUCCESS;}
}


/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit 
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L,void (*visit)(ElemType e)){
	LNode* target=L->next;
	if(target==NULL){
		printf("����Ϊ��!\n");
		return ERROR;
	}
	printf("��������Ԫ��:\n");
	for(;target!=NULL;target=target->next)
		visit(target->data);
	printf("\n");
	return SUCCESS;
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e 
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e){
	LNode* target=L->next;
	int length=0,index=-1;
	if(target==NULL)
		return ERROR;
	for(;target!=NULL;target=target->next)
	{
		length++;
		if (target->data==e)index=length;
	}
	if(index==-1)
		printf("����%d��ѭ�������в�����\n",e);
	else
		printf("����%d�ڵ�%d��λ��\n",e,index);
	return SUCCESS;
} 

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list 
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
	LNode* q,*p; 
	p=(*L)->next; 
	while(p->next!=NULL){ 
	q=p->next; 
	p->next=q->next; 
	q->next=(*L)->next; 
	(*L)->next=q; 
	} 
	return SUCCESS;
} 	

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L){
	    /*�жϵ��������Ƿ��л�,��������ָ�����ж�*/
        // �ų������ݻ���ֻ��һ���������ޱջ������
        if (L ==NULL|| L->next==NULL){
            return ERROR;
        }
        LNode* slow = L;
        LNode* fast = L->next;
        while(slow != fast){
            // �жϿ�ָ�����Ƿ�Ϊnull�����Ϊnull����˵�����ﵥ�������Ľ�β�ˡ�
            if(fast == NULL || fast->next == NULL){
                return ERROR;
            }
            slow = slow->next;
            fast = fast->next->next;
        }
        return SUCCESS;
}


/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish 
 */
LNode* ReverseEvenList(LinkedList *L){
	LNode *p,*q;
	int temp;
	p=(*L)->next;
	if(p->next==NULL)
		return ERROR;
	else{
		while(p!=NULL){
			q=p->next;
			if(q==NULL)break;
			else{
			temp=p->data;p->data=q->data;q->data=temp;
			p=p->next->next;}
		}
		return SUCCESS;
	}	
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish 
 */
LNode* FindMidNode(LinkedList *L) {
	if((*L)->next==NULL){
		printf("����Ϊ��!\n");
		return ERROR;}
	LNode* fast,*slow;
	int k=1;
	fast=slow=(*L)->next;
	fast=(*L)->next;
	while (fast->next&&fast->next->next )  
   	{  
        fast = fast->next->next;  
        slow = slow->next;
		k++;  
    }
	printf("�м���λ��Ϊ:%d\n",k);
	printf("�м��������Ϊ:%d\n",slow->data);
	return SUCCESS;  
}
